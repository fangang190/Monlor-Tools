appname=httpfile
uci del monlor.$appname.port
uci del monlor.$appname.path